import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Zap, FileText, Users, CreditCard, Shield, ArrowRight } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="flex min-h-svh flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Zap className="h-4 w-4" />
            </div>
            <span className="font-semibold text-foreground">LightPath</span>
          </Link>
          <nav className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/auth/login">Connexion</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/auth/sign-up">Commencer</Link>
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="mx-auto flex max-w-6xl flex-col items-center px-4 pt-20 pb-16 text-center md:px-6 md:pt-32 md:pb-24">
        <div className="inline-flex items-center rounded-full border border-border bg-muted px-3 py-1 text-xs font-medium text-muted-foreground mb-6">
          Concu pour les auto-entrepreneurs francais
        </div>
        <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground md:text-6xl lg:text-7xl">
          La facturation{' '}
          <span className="text-primary">simplifiee</span>
        </h1>
        <p className="mt-6 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl leading-relaxed">
          Creez vos factures et devis en quelques clics. LightPath est
          l{"'"}outil de facturation concu pour les auto-entrepreneurs
          qui veulent se concentrer sur leur activite.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Button size="lg" asChild>
            <Link href="/auth/sign-up">
              Creer mon compte gratuitement
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link href="/auth/login">
              Se connecter
            </Link>
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="border-t border-border bg-muted/30">
        <div className="mx-auto max-w-6xl px-4 py-16 md:px-6 md:py-24">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl text-balance">
              Tout ce dont vous avez besoin
            </h2>
            <p className="mt-3 text-muted-foreground text-pretty">
              Un outil complet pour gerer votre activite d{"'"}auto-entrepreneur.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: FileText,
                title: 'Factures et devis',
                description:
                  'Creez des factures et devis professionnels conformes a la legislation francaise.',
              },
              {
                icon: Users,
                title: 'Gestion clients',
                description:
                  'Centralisez les informations de vos clients et retrouvez leur historique.',
              },
              {
                icon: CreditCard,
                title: 'Suivi des paiements',
                description:
                  'Suivez les paiements recus et identifiez les factures en retard.',
              },
              {
                icon: Shield,
                title: 'Conforme TVA',
                description:
                  'Mention automatique "TVA non applicable, art. 293 B du CGI" sur vos documents.',
              },
            ].map((feature) => (
              <div
                key={feature.title}
                className="flex flex-col gap-3 rounded-lg border border-border bg-card p-6"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <feature.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-16 text-center md:px-6 md:py-24">
          <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl text-balance">
            Pret a simplifier votre facturation ?
          </h2>
          <p className="mt-3 text-muted-foreground text-pretty">
            Inscrivez-vous gratuitement et commencez a facturer en quelques minutes.
          </p>
          <Button size="lg" className="mt-6" asChild>
            <Link href="/auth/sign-up">
              Commencer gratuitement
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-6 md:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-6 w-6 items-center justify-center rounded bg-primary text-primary-foreground">
              <Zap className="h-3 w-3" />
            </div>
            <span className="text-sm font-medium text-foreground">LightPath</span>
          </div>
          <p className="text-xs text-muted-foreground">
            {'Facturation pour auto-entrepreneurs'}
          </p>
        </div>
      </footer>
    </div>
  )
}
