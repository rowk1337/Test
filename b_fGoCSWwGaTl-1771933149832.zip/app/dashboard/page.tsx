import { createClient } from '@/lib/supabase/server'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { FileText, Users, CreditCard, TrendingUp } from 'lucide-react'
import { RevenueChart } from '@/components/dashboard/revenue-chart'
import { RecentInvoices } from '@/components/dashboard/recent-invoices'

export default async function DashboardPage() {
  const supabase = await createClient()

  const [
    { count: clientCount },
    { count: invoiceCount },
    { data: invoices },
    { data: payments },
  ] = await Promise.all([
    supabase.from('clients').select('*', { count: 'exact', head: true }),
    supabase.from('invoices').select('*', { count: 'exact', head: true }),
    supabase.from('invoices').select('id, total, status, created_at').order('created_at', { ascending: false }).limit(5),
    supabase.from('payments').select('amount'),
  ])

  const totalRevenue = payments?.reduce((sum, p) => sum + Number(p.amount), 0) ?? 0
  const pendingInvoices = invoices?.filter((i) => i.status === 'sent' || i.status === 'draft').length ?? 0

  const kpis = [
    {
      title: 'Chiffre d\'affaires',
      value: new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(totalRevenue),
      icon: TrendingUp,
      description: 'Total encaisse',
    },
    {
      title: 'Clients',
      value: String(clientCount ?? 0),
      icon: Users,
      description: 'Clients actifs',
    },
    {
      title: 'Factures',
      value: String(invoiceCount ?? 0),
      icon: FileText,
      description: `${pendingInvoices} en attente`,
    },
    {
      title: 'Paiements',
      value: String(payments?.length ?? 0),
      icon: CreditCard,
      description: 'Paiements recus',
    },
  ]

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Tableau de bord</h1>
        <p className="text-muted-foreground">Vue d{"'"}ensemble de votre activite</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {kpis.map((kpi) => (
          <Card key={kpi.title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {kpi.title}
              </CardTitle>
              <kpi.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{kpi.value}</div>
              <p className="text-xs text-muted-foreground">{kpi.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle className="text-foreground">Revenus mensuels</CardTitle>
          </CardHeader>
          <CardContent>
            <RevenueChart />
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-foreground">Factures recentes</CardTitle>
          </CardHeader>
          <CardContent>
            <RecentInvoices invoices={invoices ?? []} />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
