import { createClient } from '@/lib/supabase/server'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { CreditCard } from 'lucide-react'

const methodLabels: Record<string, string> = {
  bank_transfer: 'Virement',
  check: 'Cheque',
  cash: 'Especes',
  card: 'Carte',
  other: 'Autre',
}

export default async function PaymentsPage() {
  const supabase = await createClient()
  const { data: payments } = await supabase
    .from('payments')
    .select('*, invoices(invoice_number)')
    .order('payment_date', { ascending: false })

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Paiements</h1>
        <p className="text-muted-foreground">Historique des paiements recus</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Liste des paiements</CardTitle>
        </CardHeader>
        <CardContent>
          {!payments || payments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <CreditCard className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium text-foreground">Aucun paiement</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Les paiements apparaitront ici une fois enregistres.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Facture</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Montant</TableHead>
                  <TableHead>Methode</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.map((payment) => {
                  const invoice = payment.invoices as { invoice_number?: string } | null
                  return (
                    <TableRow key={payment.id}>
                      <TableCell className="font-mono text-sm text-foreground">
                        {invoice?.invoice_number ?? '-'}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {new Date(payment.payment_date).toLocaleDateString('fr-FR')}
                      </TableCell>
                      <TableCell className="font-medium text-foreground">
                        {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(Number(payment.amount))}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {methodLabels[payment.payment_method] ?? payment.payment_method}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {payment.notes || '-'}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
