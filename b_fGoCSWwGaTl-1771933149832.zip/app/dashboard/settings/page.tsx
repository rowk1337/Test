import { createClient } from '@/lib/supabase/server'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'

export default async function SettingsPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  let profile = null
  if (user) {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single()
    profile = data
  }

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Parametres</h1>
        <p className="text-muted-foreground">Configurez votre profil et votre activite</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Informations personnelles</CardTitle>
          <CardDescription>Vos informations de base</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="first_name">Prenom</Label>
              <Input
                id="first_name"
                defaultValue={profile?.first_name ?? ''}
                placeholder="Jean"
                readOnly
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="last_name">Nom</Label>
              <Input
                id="last_name"
                defaultValue={profile?.last_name ?? ''}
                placeholder="Dupont"
                readOnly
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              defaultValue={user?.email ?? ''}
              readOnly
              className="text-muted-foreground"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Informations professionnelles</CardTitle>
          <CardDescription>Vos informations d{"'"}auto-entrepreneur</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="siret">SIRET</Label>
              <Input
                id="siret"
                defaultValue={profile?.siret ?? ''}
                placeholder="123 456 789 00012"
                readOnly
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="activity_type">Type d{"'"}activite</Label>
              <Input
                id="activity_type"
                defaultValue={profile?.activity_type ?? ''}
                placeholder="Prestation de services"
                readOnly
              />
            </div>
          </div>

          <Separator />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="address">Adresse</Label>
              <Input
                id="address"
                defaultValue={profile?.address ?? ''}
                placeholder="1 rue de la Paix"
                readOnly
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="city">Ville</Label>
              <Input
                id="city"
                defaultValue={profile?.city ?? ''}
                placeholder="Paris"
                readOnly
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="postal_code">Code postal</Label>
              <Input
                id="postal_code"
                defaultValue={profile?.postal_code ?? ''}
                placeholder="75001"
                readOnly
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="phone">Telephone</Label>
              <Input
                id="phone"
                defaultValue={profile?.phone ?? ''}
                placeholder="06 12 34 56 78"
                readOnly
              />
            </div>
          </div>

          <div className="rounded-lg border border-border bg-muted/50 p-4">
            <p className="text-sm text-muted-foreground">
              {"TVA non applicable, art. 293 B du CGI"}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Cette mention sera automatiquement ajoutee a vos factures.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
