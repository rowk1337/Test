import { createClient } from '@/lib/supabase/server'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Plus, FilePenLine } from 'lucide-react'

const statusLabels: Record<string, string> = {
  draft: 'Brouillon',
  sent: 'Envoye',
  accepted: 'Accepte',
  rejected: 'Refuse',
  expired: 'Expire',
}

const statusVariants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  draft: 'secondary',
  sent: 'outline',
  accepted: 'default',
  rejected: 'destructive',
  expired: 'secondary',
}

export default async function QuotesPage() {
  const supabase = await createClient()
  const { data: quotes } = await supabase
    .from('quotes')
    .select('*, clients(company_name, first_name, last_name)')
    .order('created_at', { ascending: false })

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Devis</h1>
          <p className="text-muted-foreground">Creez et gerez vos devis</p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Nouveau devis
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Liste des devis</CardTitle>
        </CardHeader>
        <CardContent>
          {!quotes || quotes.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FilePenLine className="h-12 w-12 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium text-foreground">Aucun devis</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Creez votre premier devis pour commencer.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Numero</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Validite</TableHead>
                  <TableHead>Montant TTC</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {quotes.map((quote) => {
                  const client = quote.clients as { company_name?: string; first_name?: string; last_name?: string } | null
                  const clientName = client?.company_name || `${client?.first_name ?? ''} ${client?.last_name ?? ''}`.trim() || '-'
                  return (
                    <TableRow key={quote.id}>
                      <TableCell className="font-mono text-sm text-foreground">
                        {quote.quote_number}
                      </TableCell>
                      <TableCell className="text-foreground">{clientName}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {new Date(quote.issue_date).toLocaleDateString('fr-FR')}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {new Date(quote.validity_date).toLocaleDateString('fr-FR')}
                      </TableCell>
                      <TableCell className="font-medium text-foreground">
                        {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(Number(quote.total))}
                      </TableCell>
                      <TableCell>
                        <Badge variant={statusVariants[quote.status] ?? 'secondary'}>
                          {statusLabels[quote.status] ?? quote.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          Voir
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
