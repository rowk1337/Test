import { Badge } from '@/components/ui/badge'

interface Invoice {
  id: string
  total: number
  status: string
  created_at: string
}

const statusLabels: Record<string, string> = {
  draft: 'Brouillon',
  sent: 'Envoyee',
  paid: 'Payee',
  overdue: 'En retard',
  cancelled: 'Annulee',
}

const statusVariants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  draft: 'secondary',
  sent: 'outline',
  paid: 'default',
  overdue: 'destructive',
  cancelled: 'secondary',
}

export function RecentInvoices({ invoices }: { invoices: Invoice[] }) {
  if (invoices.length === 0) {
    return (
      <p className="text-sm text-muted-foreground py-8 text-center">
        Aucune facture pour le moment.
      </p>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      {invoices.map((invoice) => (
        <div key={invoice.id} className="flex items-center justify-between">
          <div className="flex flex-col gap-0.5">
            <span className="text-sm font-medium text-foreground">
              {new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(Number(invoice.total))}
            </span>
            <span className="text-xs text-muted-foreground">
              {new Date(invoice.created_at).toLocaleDateString('fr-FR')}
            </span>
          </div>
          <Badge variant={statusVariants[invoice.status] ?? 'secondary'}>
            {statusLabels[invoice.status] ?? invoice.status}
          </Badge>
        </div>
      ))}
    </div>
  )
}
