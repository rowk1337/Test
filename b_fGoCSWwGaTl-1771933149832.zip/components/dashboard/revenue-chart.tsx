'use client'

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

const placeholderData = [
  { name: 'Jan', total: 0 },
  { name: 'Fev', total: 0 },
  { name: 'Mar', total: 0 },
  { name: 'Avr', total: 0 },
  { name: 'Mai', total: 0 },
  { name: 'Jun', total: 0 },
  { name: 'Jul', total: 0 },
  { name: 'Aou', total: 0 },
  { name: 'Sep', total: 0 },
  { name: 'Oct', total: 0 },
  { name: 'Nov', total: 0 },
  { name: 'Dec', total: 0 },
]

export function RevenueChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={placeholderData}>
        <XAxis
          dataKey="name"
          stroke="oklch(0.5 0.02 260)"
          fontSize={12}
          tickLine={false}
          axisLine={false}
        />
        <YAxis
          stroke="oklch(0.5 0.02 260)"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `${value}€`}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: 'oklch(1 0 0)',
            border: '1px solid oklch(0.91 0.01 240)',
            borderRadius: '0.5rem',
            fontSize: '0.875rem',
          }}
          formatter={(value: number) => [`${value} €`, 'Revenus']}
        />
        <Bar
          dataKey="total"
          fill="oklch(0.52 0.12 230)"
          radius={[4, 4, 0, 0]}
        />
      </BarChart>
    </ResponsiveContainer>
  )
}
